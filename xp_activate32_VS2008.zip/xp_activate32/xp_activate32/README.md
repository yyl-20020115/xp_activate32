Windows XP activation tool, code found on archive.org.  Modified to build with Visual Studio 2022.  Requires a WinXP compatible platform toolset, such as "v141_xp".
